﻿namespace DefaultNamespace
{
    public interface IWipeable
    {
        public void Wipe();
    }
}