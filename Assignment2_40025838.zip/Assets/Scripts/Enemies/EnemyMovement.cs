using UnityEngine;

public class EnemyMovement: MonoBehaviour
{
    public static float BaseSpeed = 3f;
    public static float HalfSpeed => BaseSpeed /2f;

}
