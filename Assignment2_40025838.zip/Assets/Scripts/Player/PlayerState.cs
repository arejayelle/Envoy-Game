﻿namespace DefaultNamespace.Player
{
    public enum PlayerState
    {
        Chilling,
        Wiping,
        Kicking,
        Masking,
        Distancing
    }
}