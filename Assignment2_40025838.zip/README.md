
## Source
Code can also be found here: https://github.com/arejayelle/Envoy-Game 

## Controls
|Input|Keyboard|Xbox controller|
|---|--|--|
 |Movement  | Arrow keys  | left joystick|
 |Jump      | space  | A |
 |Wipe table| S  | B |  
 |Shoot mask| F   | X |
 |Social Distance | A   | Y |
 |Kick |W   | RB |   
 |Bullet Time | E   | LT |  

 // Sorry i'm a controller kid. not sure what are good keys

 ## Reading the code
 Oof. Sorry. Switched architectures throughout the project. 
 There are a few dead code files from when I tried some stuff that didn't turn out.
 Mostly referenced Brackeys 

 ## compilation
 I'm just realizing I did this is 2020.3.19 which is not the version on the lab computers so guess that sucks, eh?

## Note
I did all the sprites & animation myself :) first time doing pixel art
(I am also aware that the pixel art looks really bad blown up. I uhhh I tried.)
